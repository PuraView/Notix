
import XCTest

final class NotatUITests: XCTestCase {
    func testExample() throws {
        XCTAssertTrue(true)
    }
}
